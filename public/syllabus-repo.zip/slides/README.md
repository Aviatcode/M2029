# Lecture Slides & Handouts

Course: Database Management Systems & Relational Architectures (BCA-302)
Professor: Dr. Rajesh Sharma

Store professor presentations, lecture PDFs, and classroom handouts here.
