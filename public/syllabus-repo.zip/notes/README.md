# Class Study Notes: Database Management Systems & Relational Architectures

Instructor: Dr. Rajesh Sharma (Associate Professor & Head of Database Systems Lab)
Email: rajesh.sharma@cs.university.edu
Office: Room 402, Block B, Technology Wing

Store lecture notes, study summaries, and mindmaps here.
