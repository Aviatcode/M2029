# University Past Year Questions (PYQs)

Course: Database Management Systems & Relational Architectures (BCA-302)
University: University School of Information Technology & Engineering

Archive previous semester question papers, marking guides, and model answers here.
